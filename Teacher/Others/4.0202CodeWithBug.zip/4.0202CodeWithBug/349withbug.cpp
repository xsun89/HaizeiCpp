// 30分代码
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cstring>
#include <queue>
using namespace std;
#define MAX_N 5000

int val[MAX_N + 5];
int dp[MAX_N + 5];
int n;
int f[MAX_N + 5];
int ans, sum;

int main() {
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> val[i];
    for (int i = 1; i <= n; i++) {
        dp[i] = 1;
        for (int j = 1; j < i; j++) {
            if (val[j] > val[i]) {
                dp[i] = max(dp[i], dp[j] + 1);
            }
        }
        if(dp[i] == 1) f[i] = i;
        for (int j = 1; j < i; j++) {
            if (dp[j] + 1 != dp[i]) continue;
            if (val[j] <= val[i]) continue;
            f[i] += f[j];
        }
        for (int j = 1; j < i; j++) {
            if (val[i] == val[j] && dp[i] == dp[j]) f[i] = 0;
        }
        ans = max(ans, dp[i]);
        sum = max(sum, f[i]);
    }
    cout << ans << " " << sum << endl;
    return 0;
}
