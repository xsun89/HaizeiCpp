class Solution {
public:
    string convert(string s, int numRows) {
        if (numRows <= 1) return s;
        vector<string> res(numRows);
        string ans;
        int i_dir = -1, i = 0;
        for (char &c:s) {
            res[i] += c;
            if (i == 0 || i == numRows - 1) {
                i_dir = -i_dir;
            }
            i += i_dir;
        }
        for (string &str:res) {
            ans += str;
        }
        return ans;
    }
};
