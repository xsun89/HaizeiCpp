/*************************************************************************
	> File Name: 348withbug.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 二  2/ 2 01:04:51 2021
 ************************************************************************/

// 10分代码
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
#include <cmath>
using namespace std;
#define MAX_N 100
#define INF 0x3f3f3f3f
int val[MAX_N + 5][MAX_N + 5];
int dp[MAX_N + 5][MAX_N + 5];
int pos[MAX_N + 5][MAX_N + 5];
int ans[MAX_N + 5];

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> val[i][j];
            dp[i][j] = -INF;
        }
    }
    for (int i = 0; i <= m; i++) dp[0][i] = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = i; j <= m; j++) {
            if (dp[i][j - 1] > dp[i][j]) {
                dp[i][j] = dp[i][j - 1];
                pos[i][j] = pos[i][j - 1];
            }
            if (dp[i - 1][j - 1] + val[i][j] > dp[i][j]) {
                dp[i][j] = dp[i - 1][j - 1] + val[i][j];
                pos[i][j] = j;
            }
        }
    }
    cout << dp[n][m] << endl;
    for (int i = n, j = m; i >= 1; i--, j = pos[i][j - 1]) {
        ans[i] = j;
    }
    for (int i = 1; i <= n; i++) {
        i == 1 || cout << " ";
        cout << ans[i];
    }
    cout << endl;
    return 0;
}
