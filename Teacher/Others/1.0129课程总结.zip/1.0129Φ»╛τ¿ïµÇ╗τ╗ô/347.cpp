/*************************************************************************
	> File Name: 347.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 五  1/29 20:55:02 2021
 ************************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <queue>
using namespace std;


#define MAX_N 360
#define MAX_M 120

int a[MAX_N + 5];
int b[5];

int dp[MAX_M + 5][MAX_M + 5][MAX_M + 5][MAX_M + 5];

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < m; i++) {
        int temp;
        cin >> temp;
        b[temp]++;
    }
    for (int i = 0; i <= b[1]; i++) {
        for (int j = 0; j <= b[2]; j++) {
            for (int x = 0; x <= b[3]; x++){
                for (int y = 0; y <= b[4]; y++) {
                    if(i - 1 >= 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i - 1][j][x][y]);
                    if(j - 1 >= 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i][j - 1][x][y]);
                    if(x - 1 >= 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i][j][x - 1][y]);
                    if(y - 1 >= 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i][j][x][y - 1]);
                    dp[i][j][x][y] += a[i + j * 2 + x * 3 + y * 4];
                }
            }
        }
    }
    cout << dp[b[1]][b[2]][b[3]][b[4]] << endl;
    return 0;
}







