
class Solution {
public:
    int dir[8][2] = {
        -1, -1, -1, 0, -1, 1, 
        0, -1, 0, 1,
        1, -1, 1, 0, 1, 1
    };
    void gameOfLife(vector<vector<int>>& board) {
        for (int i = 0; i < board.size(); i++) {
            for (int j = 0; j < board[i].size(); j++) {
                int num = 0;
                for (int k = 0; k < 8; k++) {
                    int x = i + dir[k][0];
                    if (x < 0 || x >= board.size()) continue;
                    int y = j + dir[k][1];
                    if (y < 0 || y >= board[i].size()) continue;
                    num += (board[x][y] & 1);
                }
                if (board[i][j] & 1) {
                    if (num == 2 || num == 3) board[i][j] = 0b11;
                } else {
                    if (num == 3) board[i][j] = 0b10;
                }
            }
        }
        for (int i = 0; i < board.size(); i++) {
            for (int j = 0; j < board[i].size(); j++) {
                board[i][j] >>= 1;
            }
        }
        return ;
    }
};
