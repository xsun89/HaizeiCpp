/*************************************************************************
	> File Name: 346.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 五  1/29 20:09:46 2021
 ************************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <queue>
using namespace std;

#define MAX_N 50

int val[MAX_N + 5][MAX_N + 5];
int dp[2 * MAX_N + 5][MAX_N + 5][MAX_N + 5];

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> val[i][j];
        }
    }
    for (int k = 1; k <= (n + m - 1); k++) {
        for (int i = 1; i <= min(n - 1, k - 1); i++) {
            for (int j = i + 1; j <= min(n, k - 1); j++) {
                int i1 = k - i;
                int j1 = k - j;
                if ((i1 < 0 || i1 > m) || (j1 < 0 || j1 > m)) continue; 
                int tmp = max(dp[k - 1][i][j], dp[k - 1][i - 1][j]);
                tmp = max(tmp, max(dp[k - 1][i][j - 1], dp[k - 1][i - 1][j - 1]));
                dp[k][i][j] = tmp + val[i][k - i] + val[j][k - j];
            }
        }
    }
    cout << dp[n + m - 1][n - 1][n] << endl;
    return 0;
}





