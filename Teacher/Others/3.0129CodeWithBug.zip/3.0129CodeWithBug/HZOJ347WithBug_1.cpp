/*************************************************************************
	> File Name: HZOJ347WithBug_1.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 四  1/28 21:31:41 2021
 ************************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cstring>
#include <queue>
using namespace std;
#define MAX_A 350
#define MAX_B 120

int n, m;
int a[MAX_A + 5];
int b[MAX_B + 5];
int dp[MAX_B + 5][MAX_B + 5][MAX_B + 5][MAX_B + 5];

int c[5];

int main() {
    cin >> n >> m;
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 1; i <= m; i++) {
        cin >> b[i];
        c[b[i]]++;
    }
    for (int i = 0; i <= c[1]; i++) {
        for (int j = 0; j <= c[2]; j++) {
            for (int x = 0; x <= c[3]; x++) {
                for (int y = 0; y <= c[4]; y++) {
                    if (i > 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i - 1][j][x][y]);
                    if (j > 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i][j - 1][x][y]);
                    if (x > 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i][j][x - 1][y]);
                    if (y > 0) dp[i][j][x][y] = max(dp[i][j][x][y], dp[i][j][x][y - 1]);
                    dp[i][j][x][y] += a[i + j * 2 + x * 3 + y * 4];
                }
            }
        }
    }
    cout << dp[c[1]][c[2]][c[3]][c[4]] << endl;
    return 0;
}



