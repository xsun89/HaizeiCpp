/*************************************************************************
	> File Name: HZOJ348.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 二  2/ 2 19:55:30 2021
 ************************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <queue>
using namespace std;


#define MAX_N 100
#define INF 0x3f3f3f3f
int val[MAX_N + 5][MAX_N + 5];
int dp[MAX_N + 5][MAX_N + 5];
int pos[MAX_N + 5][MAX_N + 5];
int ans_pos[MAX_N + 5];


int main() {
    int f, v;
    cin >> f >> v;
    for (int i = 1; i <= f; i++) {
        dp[i][0] = -INF;
        for (int j = 1; j <= v; j++) {
            cin >> val[i][j];
            dp[i][j] = -INF;
        }
    }
    for (int i = 1; i <= f; i++) {
        for (int j = 1; j<= v; j++) {
            dp[i][j] = max(dp[i - 1][j -  1] + val[i][j], dp[i][j - 1]);
            if (dp[i - 1][j - 1] + val[i][j] > dp[i][j - 1]) {
                pos[i][j] = j;
            } else {
                pos[i][j] = pos[i][j - 1]; 
            }
        }
    }
    cout << dp[f][v] << endl;
    for (int i = f, j = pos[f][v]; i >= 1; i--, j = pos[i][j - 1]) {
        ans_pos[i] = j;
    }
    for (int i = 1; i <= f; i++) {
        if (i != 1) cout << " ";
        cout << ans_pos[i];
    }
    cout << endl;
    return 0;
}


