/*************************************************************************
	> File Name: LeetCode119.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 五  1/29 21:44:25 2021
 ************************************************************************/

class Solution {
public:
    int gcd(int a, int b) {
        return b ? gcd(b , a % b) : a;
    }
    vector<int> getRow(int rowIndex) {
        vector<int> ans(rowIndex + 1, 1);
        for (int i = 1; i < rowIndex; i++) {
            int a = gcd(ans[i - 1], i);
            int b = i / a;
            ans[i] = (ans[i - 1] / a) * ((rowIndex - i + 1) / b);
        }
        return ans;
    }
};

