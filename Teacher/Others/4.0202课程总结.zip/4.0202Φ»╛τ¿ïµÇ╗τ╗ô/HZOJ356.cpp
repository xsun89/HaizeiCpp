/*************************************************************************
	> File Name: HZOJ356.cpp
	> Author: ZhangZe
	> Mail: zhang_ze_mail@163.com
	> Created Time: 二  2/ 2 20:49:27 2021
 ************************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <queue>
using namespace std;
#define MAX_N 300
#define INF 0x3f3f3f3f
int dp[MAX_N + 5][MAX_N + 5];
int val[MAX_N + 5];

int main() {
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> val[i], val[i] += val[i - 1];
    for (int l = 2; l <= n; l++) {
        for (int i = 1; i <= n - l + 1; i++) {
            int j = i + l - 1;
            dp[i][j] = INF;
            for (int k = i; k <= j; k++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + val[j] - val[i - 1]);
            }
        }
    }
    cout << dp[1][n] << endl;
    return 0;
}



